# Library Management System (Java, OOP, MySQL, JDBC)

Console-based app: book inventory, member registration, issue/return tracking, fine calculation (Rs. 5/day after 14 days).

## Setup
1. Run `schema.sql` in MySQL.
2. Add the MySQL Connector/J jar to the project's build path (Eclipse: Right-click project > Build Path > Add External JARs).
3. Set env var `DB_PASSWORD` (or edit `DBConnection.java`).
4. Run `Main.java` (Java 14+ required for the switch syntax).

## Structure
- `Book`, `Member` - model classes
- `DBConnection` - JDBC connection
- `LibraryService` - all database operations (PreparedStatements, transactions)
- `Main` - menu-driven console UI
