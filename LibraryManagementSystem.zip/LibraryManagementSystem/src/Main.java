import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static final LibraryService service = new LibraryService();

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n===== LIBRARY MANAGEMENT SYSTEM =====");
            System.out.println("1. Add Book");
            System.out.println("2. View / Search Books");
            System.out.println("3. Register Member");
            System.out.println("4. View Members");
            System.out.println("5. Issue Book");
            System.out.println("6. Return Book");
            System.out.println("7. View Issued Books");
            System.out.println("0. Exit");
            int choice = readInt("Enter choice: ");
            try {
                switch (choice) {
                    case 1 -> addBook();
                    case 2 -> searchBooks();
                    case 3 -> registerMember();
                    case 4 -> viewMembers();
                    case 5 -> System.out.println(service.issueBook(readInt("Book ID: "), readInt("Member ID: ")));
                    case 6 -> System.out.println(service.returnBook(readInt("Book ID: "), readInt("Member ID: ")));
                    case 7 -> service.printIssuedBooks();
                    case 0 -> { System.out.println("Goodbye!"); return; }
                    default -> System.out.println("Invalid choice.");
                }
            } catch (SQLException e) {
                System.out.println("Database error: " + e.getMessage());
            }
        }
    }

    private static void addBook() throws SQLException {
        System.out.print("Title: ");
        String title = sc.nextLine().trim();
        System.out.print("Author: ");
        String author = sc.nextLine().trim();
        int copies = readInt("Copies: ");
        if (title.isEmpty() || author.isEmpty() || copies <= 0) {
            System.out.println("Invalid input.");
            return;
        }
        service.addBook(title, author, copies);
        System.out.println("Book added.");
    }

    private static void searchBooks() throws SQLException {
        System.out.print("Search keyword (blank = all): ");
        List<Book> books = service.getBooks(sc.nextLine().trim());
        if (books.isEmpty()) { System.out.println("No books found."); return; }
        System.out.printf("%-5s %-30s %-20s %s%n", "ID", "Title", "Author", "Avail/Total");
        books.forEach(System.out::println);
    }

    private static void registerMember() throws SQLException {
        System.out.print("Name: ");
        String name = sc.nextLine().trim();
        System.out.print("Email: ");
        String email = sc.nextLine().trim();
        System.out.print("Phone: ");
        String phone = sc.nextLine().trim();
        if (name.isEmpty() || !email.contains("@")) {
            System.out.println("Invalid name or email.");
            return;
        }
        service.registerMember(name, email, phone);
        System.out.println("Member registered.");
    }

    private static void viewMembers() throws SQLException {
        List<Member> members = service.getMembers();
        if (members.isEmpty()) { System.out.println("No members yet."); return; }
        System.out.printf("%-5s %-20s %-28s %s%n", "ID", "Name", "Email", "Phone");
        members.forEach(System.out::println);
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
}
