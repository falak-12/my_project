import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class LibraryService {
    private static final int LOAN_DAYS = 14;
    private static final double FINE_PER_DAY = 5.0; // Rs. per day after due date

    // ---------- Books ----------
    public void addBook(String title, String author, int copies) throws SQLException {
        String sql = "INSERT INTO books (title, author, total_copies, available_copies) VALUES (?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, title);
            ps.setString(2, author);
            ps.setInt(3, copies);
            ps.setInt(4, copies);
            ps.executeUpdate();
        }
    }

    public List<Book> getBooks(String keyword) throws SQLException {
        String sql = "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? ORDER BY title";
        List<Book> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            String like = "%" + keyword + "%";
            ps.setString(1, like);
            ps.setString(2, like);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Book(rs.getInt("book_id"), rs.getString("title"),
                            rs.getString("author"), rs.getInt("total_copies"),
                            rs.getInt("available_copies")));
                }
            }
        }
        return list;
    }

    // ---------- Members ----------
    public void registerMember(String name, String email, String phone) throws SQLException {
        String sql = "INSERT INTO members (name, email, phone) VALUES (?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, phone);
            ps.executeUpdate();
        }
    }

    public List<Member> getMembers() throws SQLException {
        List<Member> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM members ORDER BY name")) {
            while (rs.next()) {
                list.add(new Member(rs.getInt("member_id"), rs.getString("name"),
                        rs.getString("email"), rs.getString("phone")));
            }
        }
        return list;
    }

    // ---------- Issue / Return ----------
    public String issueBook(int bookId, int memberId) throws SQLException {
        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try {
                if (!exists(con, "SELECT 1 FROM members WHERE member_id = ?", memberId))
                    return "Member not found.";

                int available;
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT available_copies FROM books WHERE book_id = ? FOR UPDATE")) {
                    ps.setInt(1, bookId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) return "Book not found.";
                        available = rs.getInt(1);
                    }
                }
                if (available <= 0) return "No copies available right now.";

                if (exists(con, "SELECT 1 FROM transactions WHERE book_id = ? AND member_id = ? AND return_date IS NULL",
                        bookId, memberId))
                    return "This member already has this book.";

                LocalDate today = LocalDate.now();
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO transactions (book_id, member_id, issue_date, due_date) VALUES (?, ?, ?, ?)")) {
                    ps.setInt(1, bookId);
                    ps.setInt(2, memberId);
                    ps.setDate(3, Date.valueOf(today));
                    ps.setDate(4, Date.valueOf(today.plusDays(LOAN_DAYS)));
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE books SET available_copies = available_copies - 1 WHERE book_id = ?")) {
                    ps.setInt(1, bookId);
                    ps.executeUpdate();
                }
                con.commit();
                return "Book issued. Due date: " + today.plusDays(LOAN_DAYS);
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        }
    }

    public String returnBook(int bookId, int memberId) throws SQLException {
        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try {
                int txnId;
                LocalDate due;
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT txn_id, due_date FROM transactions " +
                        "WHERE book_id = ? AND member_id = ? AND return_date IS NULL")) {
                    ps.setInt(1, bookId);
                    ps.setInt(2, memberId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) return "No active issue record found.";
                        txnId = rs.getInt("txn_id");
                        due = rs.getDate("due_date").toLocalDate();
                    }
                }

                LocalDate today = LocalDate.now();
                long lateDays = Math.max(0, ChronoUnit.DAYS.between(due, today));
                double fine = lateDays * FINE_PER_DAY;

                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE transactions SET return_date = ?, fine = ? WHERE txn_id = ?")) {
                    ps.setDate(1, Date.valueOf(today));
                    ps.setDouble(2, fine);
                    ps.setInt(3, txnId);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE books SET available_copies = available_copies + 1 WHERE book_id = ?")) {
                    ps.setInt(1, bookId);
                    ps.executeUpdate();
                }
                con.commit();
                return fine > 0
                        ? "Book returned " + lateDays + " day(s) late. Fine: Rs. " + fine
                        : "Book returned on time. No fine.";
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        }
    }

    public void printIssuedBooks() throws SQLException {
        String sql = "SELECT t.txn_id, b.title, m.name, t.issue_date, t.due_date " +
                     "FROM transactions t JOIN books b ON t.book_id = b.book_id " +
                     "JOIN members m ON t.member_id = m.member_id WHERE t.return_date IS NULL";
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            System.out.printf("%-6s %-28s %-18s %-12s %-12s%n", "TxnID", "Book", "Member", "Issued", "Due");
            boolean any = false;
            while (rs.next()) {
                any = true;
                System.out.printf("%-6d %-28s %-18s %-12s %-12s%n", rs.getInt(1), rs.getString(2),
                        rs.getString(3), rs.getDate(4), rs.getDate(5));
            }
            if (!any) System.out.println("No books currently issued.");
        }
    }

    private boolean exists(Connection con, String sql, int... params) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) ps.setInt(i + 1, params[i]);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }
}
